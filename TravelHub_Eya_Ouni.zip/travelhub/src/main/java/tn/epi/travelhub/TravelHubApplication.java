package tn.epi.travelhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelHubApplication {

    public static void main(String[] args) {
        SpringApplication.run(TravelHubApplication.class, args);
    }
}
